"use client";

import { toast as sonnerToast } from "sonner";

export const toast = sonnerToast;