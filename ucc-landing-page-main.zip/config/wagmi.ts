// import { getDefaultConfig } from "@rainbow-me/rainbowkit";
// import { bsc } from "viem/chains";

// export const config = getDefaultConfig({
//   appName: "Gpt bot",
//   projectId: "gpt-bot",
//   chains: [bsc],
// });